import{a as r}from"./addDays-B02y5A7x.js";function t(a,s){return r(a,-s)}export{t as s};
